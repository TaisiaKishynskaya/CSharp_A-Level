﻿using Microsoft.AspNetCore.Mvc;

namespace Mod4.Lection1.Hw2.Controllers;


[ApiController]
[Route("[controller]")]
public class UserController : ControllerBase
{
    
}
